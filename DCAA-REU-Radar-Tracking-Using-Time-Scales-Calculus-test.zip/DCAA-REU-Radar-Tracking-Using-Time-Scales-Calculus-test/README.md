# DCAA-REU-Radar-Tracking-Using-Time-Scales-Calculus
Collaboration with Davis Funk translating Mathematica code to Python. Will be programming a mu-discretized Kaman Filter
